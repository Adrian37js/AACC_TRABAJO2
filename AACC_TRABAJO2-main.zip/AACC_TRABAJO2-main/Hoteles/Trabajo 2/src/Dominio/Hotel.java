package Dominio;

import java.util.ArrayList;


import Persistencia.HotelDao;

public class Hotel {
	
	//Atirbutos 
	private int id;
	private String nombre;
	private String foto;
	private int tel;
	private String direccion;
	private String ciudad;
	private String pais;
	private int numestrellas;
	private int hab_indi;
	private int hab_dobles;
	private int hab_triples;
	private int suites;
	private HotelDao gc;

	//Constructor
	 public Hotel(int id, String nombre, String foto, int tel, String direccion, String ciudad, String pais, int numestrellas,
			int hab_indi, int hab_dobles, int hab_triples, int suites) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.foto = foto;
		this.tel = tel;
		this.direccion = direccion;
		this.ciudad = ciudad;
		this.pais = pais;
		this.numestrellas = numestrellas;
		this.hab_indi = hab_indi;
		this.hab_dobles = hab_dobles;
		this.hab_triples = hab_triples;
		this.suites = suites;
		HotelDao gc = new HotelDao();

	 }
	 
	 //Constructor vacio para el DAO
	  public Hotel(){
		  HotelDao gc = new HotelDao();
	    }

	 

	 //Atributos
	 public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public int getTel() {
		return tel;
	}


	public void setTel(int tel) {
		this.tel = tel;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public String getCiudad() {
		return ciudad;
	}


	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}


	public String getPais() {
		return pais;
	}


	public void setPais(String pais) {
		this.pais = pais;
	}


	public int getNumestrellas() {
		return numestrellas;
	}


	public void setNumestrellas(int numestrellas) {
		this.numestrellas = numestrellas;
	}


	public int getHab_indi() {
		return hab_indi;
	}


	public void setHab_indi(int hab_indi) {
		this.hab_indi = hab_indi;
	}


	public int getHab_dobles() {
		return hab_dobles;
	}


	public void setHab_dobles(int hab_dobles) {
		this.hab_dobles = hab_dobles;
	}


	public int getHab_triples() {
		return hab_triples;
	}


	public void setHab_triples(int hab_triples) {
		this.hab_triples = hab_triples;
	}


	public int getSuites() {
		return suites;
	}


	public void setSuites(int suites) {
		this.suites = suites;
	}


	public HotelDao getGc() {
		return gc;
	}


	public void setGc(HotelDao gc) {
		this.gc = gc;
	}

	//Metodo para LEER y ESCRIBIR
	public void escribirXML(ArrayList<Hotel> lista){
	        gc.escribirXML(lista);
	    }

    public ArrayList<Hotel> leerXML() {
    return gc.leerXML();
    }
    
    //Metodo para imprimir TODO
	@Override
	public String toString() {
		return "Hotel [ id: " + id + ", nombre: " + nombre + ", foto: " + foto + ", tel=" + tel + ", direccion=" + direccion + ", ciudad="
				+ ciudad + ", pais=" + pais + ", numestrellas=" + numestrellas + ", hab_indi=" + hab_indi
				+ ", hab_dobles=" + hab_dobles + ", hab_triples=" + hab_triples + ", suites=" + suites + "]";
	}
}