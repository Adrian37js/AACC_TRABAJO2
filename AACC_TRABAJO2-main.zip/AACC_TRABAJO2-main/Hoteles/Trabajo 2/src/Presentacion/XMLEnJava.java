package Presentacion;

import java.io.File;

import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import Dominio.Hotel;

public class XMLEnJava {
	static boolean salto = false;

	public static void main(String[] args) {
		ArrayList<Hotel> lista = new ArrayList<Hotel>();

		Scanner sc = new Scanner(System.in);

		Hotel hotel = new Hotel();
		lista = hotel.leerXML();

		boolean seguir = true;
		System.err.println("****Informaci�n---No puede haber 2 hoteles con el mismo telefono ni  puede haber 2 hoteles con el mismo nombre en la misma direcci�n****");

		while (seguir) {

			// menu
			System.out.println("�Que deseas hacer?\n1. A�adir Hotel\n2. Modificar"
					+ " Hotel\n3. Eliminar Hotel\n4. Imprimir los Hoteles existentes"
					+ "\n5. Buscar un hotel\n6. Log out");
			int opcion = 0;
			do {
				try {
					opcion = sc.nextInt();
					salto = true;
				} catch (InputMismatchException e) {
					System.err.println("Introduzca n�meros");
					sc.nextLine();
					salto = false;
				}

				switch (opcion) {
				case 1:
					anadirHotel(lista, sc);
					break;

				case 2:
					modificarHotel(lista, sc);
					break;

				case 3:
					eliminarHotel(lista, sc);
					break;

				case 4:
					leerHotelesLista(lista);
					break;

				case 5:
					buscarHotel(lista, sc);
					break;

				case 6:
					System.out.println("Hasta pronto");
					seguir = false;
					break;

				default:
					System.out.println("Opci�n incorrecta. Del 1 al 6");

					break;
				}
			} while (opcion > 6 || opcion < 1); // limitamos opciones
		}

	}

	// Recorremos todos los hoteles del XML
	public static void leerHotelesLista(ArrayList<Hotel> lista) {
		for (int i = 0; i < lista.size(); i++) {

			System.out.println(lista.get(i).toString());
		}
	}

	// A�adimos hoteles
	public static void anadirHotel(ArrayList<Hotel> lista, Scanner sc) {

		// a�adir hotel a la lista
		boolean seguir = true;
		String nombre, direccion;

		int id = 0;
		sc.nextLine();
		
		do {
			seguir = true;
			
			System.out.println("Dime el nombre del hotel");
			nombre = sc.nextLine();

			System.out.println("Dime la direccion: ");
			direccion = sc.nextLine();
			

			for (int i = 0; i < lista.size(); i++) {

				if (lista.get(i).getNombre().equals(nombre) && lista.get(i).getDireccion().equals(direccion)) {
					seguir = false;
					System.err.println("�No puede haber un hotel con el mismo nombre en la misma direcci�n!");
				}
			}
		} while (seguir == false);

		int tel = 0;
		seguir = false;

		// Pedimos telefono
		do {
			try {
				System.out.println("Dime el telefono");
				tel = sc.nextInt();
				seguir = true;
			} catch (InputMismatchException e) {
				System.err.println("Introduzca n�meros");
				sc.next();
			}

			for (int i = 0; i < lista.size(); i++) {

				if (lista.get(i).getTel() == tel) {
					seguir = false;
					System.err.println("Este telefono ya lo tiene el hotel con id: " +  lista.get(i).getId() + " y nombre : " + lista.get(i).getNombre());
				}
			}
		} while (seguir == false);

		sc.nextLine();

		// Pedimos datos String

		System.out.println("Dime la ciudad: ");
		String ciudad = sc.nextLine();

		System.out.println("Dime el pais: ");
		String pais = sc.nextLine();
		
		System.out.println("Dime el nombre de la foto: ");
		String foto = sc.nextLine();

		// Pedimos estrellas del hotel
		int numestrellas = 0;
		boolean seguir_1 = false;

		do {
			try {
				System.out.println("Dime el n�mero de estrellas del hotel");
				numestrellas = sc.nextInt();
				seguir_1 = true;
			} catch (InputMismatchException e) {
				System.err.println("Introduzca n�meros");
				sc.nextLine();
			}
		} while (seguir_1 == false);

		// Pedimos habitaciones 1
		boolean seguir_2 = false;
		int hab_indi = 0;

		do {
			try {
				System.out.println("Dime el n�mero de habitaciones individuales");
				hab_indi = sc.nextInt();
				seguir_2 = true;
			} catch (InputMismatchException e) {
				System.err.println("Introduzca n�meros");
				sc.nextLine();
			}
		} while (seguir_2 == false);

		// Pedimos Habitaciones 2
		boolean seguir_3 = false;
		int hab_dobles = 0;
		do {
			try {
				System.out.println("Dime el n�mero de habitaciones dobles");
				hab_dobles = sc.nextInt();
				seguir_3 = true;
			} catch (InputMismatchException e) {
				System.err.println("Introduzca n�meros");
				sc.nextLine();
			}
		} while (seguir_3 == false);

		// Pedimos habitaciones habitaciones 3
		boolean seguir_4 = false;
		int hab_triples = 0;
		do {
			try {
				System.out.println("Dime el n�mero de habitaciones triples");
				hab_triples = sc.nextInt();
				seguir_4 = true;
			} catch (InputMismatchException e) {
				System.err.println("Introduzca n�meros");
				sc.nextLine();
			}
		} while (seguir_4 == false);

		// Pedimos suits
		boolean seguir_5 = false;
		int suites = 0;
		do {
			try {
				System.out.println("Dime el n�mero de suites que tiene");
				suites = sc.nextInt();
				seguir_5 = true;
			} catch (InputMismatchException e) {
				System.err.println("Introduzca n�meros");
				sc.nextLine();
			}
		} while (seguir_5 == false);

		// A�adimos por defecto el ID
		for (int i = 0; i <= lista.size(); i++) {
			id = lista.size() + 1;
		}

		// A�adimos el hotel
		Hotel newHotel = new Hotel(id, nombre, foto, tel, direccion, ciudad, pais, numestrellas, hab_indi, hab_dobles,
				hab_triples, suites);
		lista.add(newHotel);
		System.out.println("Hotel a�adido con exito");

		// a�adir al XML
		newHotel.escribirXML(lista);
	}

	// modificar coche a la lista
	public static void modificarHotel(ArrayList<Hotel> lista, Scanner sc) {
		int id = -1;
		do {

			System.out.println();
			boolean seguir = false;
			do {
				id = -1;

				// Pedimos el ID para modificar
				try {
					leerHotelesLista(lista);

					System.out.print("\n�Que hotel deseas modificar?\n ID: ");
					id = sc.nextInt();
					seguir = true;
				} catch (InputMismatchException e) {
					System.err.println("Introduzca n�meros");
					sc.nextLine();
				}
			} while (seguir == false);

			// Limitamos el ID
			if (id > lista.size() || id <= 0) {
				System.err.println("Dime un id de un hotel v�lido");
			}
		} while (id > lista.size() || id <= 0);

		// Listamos las cosas que podemos modificar
		int opcion = 0;
		do {

			boolean seguir = false;
			do {

				try {
					System.out
							.print("\n ***Men�*** \n1. Nombre\n2. Telefono\n3. Direcci�n\n4. Ciudad\n5. Pais\n6."
									+ " N�mero de estrellas\n7. Habitaciones individuales\n8. Habitaciones dobles\n9. Habitaciones triples \n10.Suits \n11.Foto \n�Que deseas modificar?: ");
					opcion = sc.nextInt();
					seguir = true;
				} catch (InputMismatchException e) {
					System.err.println("Introduzca n�meros");
					sc.nextLine();
				}
			} while (seguir == false);

			// Apartir de aqui pedimos los atributos del hotel menos el ID ya que s epone
			// por defecto
			sc.nextLine();
			switch (opcion) {

			// Telefono
			case 1:
				String nombre;
				do {
					seguir = true;
					
					System.out.println("Dime el nombre del hotel");
					nombre = sc.nextLine();				

					for (int i = 0; i < lista.size(); i++) {

						if (lista.get(i).getNombre().equals(nombre) && lista.get(i).getDireccion().equals(lista.get(id).getDireccion())) {
							seguir = false;
							System.err.println("�No puede haber un hotel con el mismo nombre en la misma direcci�n!");
						}
					}
				} while (seguir == false);
				
				lista.get(id - 1).setNombre(nombre);
				// a�adir al XML
				lista.get(id - 1).escribirXML(lista);
				System.out.println("Modificado con exito");
				break;
				
			case 2:
				seguir = false;
				int tel = 0;
				do {
					try {
						System.out.println("Introduce el telefono: ");
						tel = sc.nextInt();
						seguir = true;

						for (int i = 0; i < lista.size(); i++) {

							if (lista.get(i).getTel() == tel) {
								seguir = false;
								System.err.println("Un hotel ya tiene el mismo telefono - id: " + lista.get(i).getId());
							}
						}
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				lista.get(id - 1).setTel(tel);
				// a�adir al XML
				lista.get(id - 1).escribirXML(lista);
				System.out.println("Modificado con exito");

				break;

			// Direcci�n
			case 3:
				
				String direccion;
				do {
					seguir = true;
					
					System.out.println("Introduce la nueva Direccion");
					direccion = sc.nextLine();		

					for (int i = 0; i < lista.size(); i++) {

						if (lista.get(i).getDireccion().equals(direccion) && lista.get(i).getNombre().equals(lista.get(id).getNombre())) {
							seguir = false;
							System.err.println("�No puede haber dos hoteles con la misma direccion y el mismo nombre!");
						}
					}
				} while (seguir == false);

				lista.get(id - 1).setDireccion(direccion);
				// a�adir al XML
				lista.get(id - 1).escribirXML(lista);
				System.out.println("Modificado con exito");
				break;

			// Ciudad
			case 4:
				System.out.println("Introduce la CIUDAD");
				String ciudad = sc.next();
				lista.get(id - 1).setCiudad(ciudad);
				// a�adir al XML
				lista.get(id - 1).escribirXML(lista);
				System.out.println("Modificado con exito");
				break;

			// Pais
			case 5:
				System.out.println("Introduce el PAIS");
				String pais = sc.next();
				lista.get(id - 1).setPais(pais);
				// a�adir al XML
				lista.get(id - 1).escribirXML(lista);
				System.out.println("Modificado con exito");
				break;

			// Numero de estrellas
			case 6:
				seguir = false;
				do {
					try {
						System.out.println("Introduce el numero de estrellas");
						int numestrellas = sc.nextInt();
						lista.get(id - 1).setNumestrellas(numestrellas);
						// a�adir al XML
						lista.get(id - 1).escribirXML(lista);
						System.out.println("Modificado con exito");
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);
				break;

			// habitaciones individuales
			case 7:
				seguir = false;
				do {
					try {
						System.out.println("Introduce el numero de habitaciones individuales");
						int Hab_indi = sc.nextInt();
						lista.get(id - 1).setHab_indi(Hab_indi);
						// a�adir al XML
						lista.get(id - 1).escribirXML(lista);
						System.out.println("Modificado con exito");
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				break;

			// Habitaciones dobles
			case 8:
				seguir = false;
				do {
					try {
						System.out.println("Introduce el numero de habitaciones dobles");
						int Hab_dobles = sc.nextInt();
						lista.get(id - 1).setHab_dobles(Hab_dobles);
						lista.get(id - 1).escribirXML(lista);
						System.out.println("Modificado con exito");
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				break;

			// Habitaciones triples
			case 9:
				seguir = false;
				do {
					try {
						System.out.println("Introduce el numero de habitaciones triples");
						int hab_triples = sc.nextInt();
						lista.get(id - 1).setHab_triples(hab_triples);
						lista.get(id - 1).escribirXML(lista);
						System.out.println("Modificado con exito");
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				break;
			case 10:
				seguir = false;
				do {
					try {
						System.out.println("Introduce el numero de suites");
						int suites = sc.nextInt();
						lista.get(id - 1).setSuites(suites);
						// a�adir al XML
						lista.get(id - 1).escribirXML(lista);
						System.out.println("Modificado con exito");
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				break;
			case 11:
				System.out.println("Introduce el nombre de la foto: ");
				String foto = sc.next();

				lista.get(id - 1).setFoto(foto);
				// a�adir al XML
				lista.get(id - 1).escribirXML(lista);
				System.out.println("Modificado con exito");
				break;
			}
		} while (opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4 && opcion != 5 && opcion != 6 && opcion != 7
				&& opcion != 8 && opcion != 9 && opcion != 10);
	}

	public static void eliminarHotel(ArrayList<Hotel> lista, Scanner sc) {
// eliminar coche a la lista
		int nombre = -1;
		int id = 1;
		do {
			boolean seguir = false;
			do {
				nombre = -1;
				try {
					System.out.println("�Que hotel deseas eliminar?");
					leerHotelesLista(lista);
					nombre = sc.nextInt();
					seguir = true;
				} catch (InputMismatchException e) {
					System.err.println("Introduzca n�meros");
					sc.nextLine();
				}
			} while (seguir == false);

			if (nombre > lista.size() || nombre < 0) {
				System.out.println("Dime un id de un coche valido");
			}
		} while (nombre > lista.size() || nombre < 0);
		lista.remove(nombre - 1);
		System.out.println("Hotel eliminado");

// a�adir al XML
		Hotel delHotel = new Hotel();
		delHotel.escribirXML(lista);

		for (int i = 0; i < lista.size(); i++) {
			lista.get(i).setId(id);
			lista.get(id - 1).escribirXML(lista);
			id++;
		}
	}

	// Metodo para buscar hotel
	public static void buscarHotel(ArrayList<Hotel> lista, Scanner sc) {
		int opcion = 0;
		do {
			boolean seguir = false;
			do {
				try {
					// Mostramos el menu para filtrar.
					System.out.println(
							"\n�Por que deseas filtrar?\n1. Telefono\n2. Direccion\n3. Ciudad\n4. Pais\n5. Numestrellas\n6."
									+ " hab_ind\n7. hab_dobles\n8. hab_triples\n9. suites\n");
					opcion = sc.nextInt();
					seguir = true;
				} catch (InputMismatchException e) {
					System.err.println("Introduzca n�meros");
					sc.nextLine();
				}
			} while (seguir == false);

			boolean encontrado = false;
			int j = 0;

			switch (opcion) {

			// Filtro por telfono
			case 1:
				seguir = false;
				int telefono = 0;
				do {
					try {
						System.out.println("Introduce un telefono");
						telefono = sc.nextInt();
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getTel() == telefono) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel con el telefono  " + telefono);
				}
				break;

			// Filtro por direcci�n
			case 2:
				System.out.println("Introduce una Direccion");
				String direccion = sc.next();
				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getDireccion().equalsIgnoreCase(direccion)) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel con la direccion  " + direccion);
				}
				break;

			// Filtro de ciudad
			case 3:
				System.out.println("Introduce una ciudad");
				String ciudad = sc.next();
				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getCiudad().equalsIgnoreCase(ciudad)) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel en la ciudad  " + ciudad);
				}
				break;

			// Filtro por el pais
			case 4:
				System.out.println("Introduce un pais");
				String pais = sc.next();
				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getPais().equalsIgnoreCase(pais)) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel en el pais  " + pais);
				}
				break;

			// Filtro por num de estrellas
			case 5:
				seguir = false;
				int estrellas = 0;
				do {
					try {
						System.out.println("Introduce el numero de estrellas");
						estrellas = sc.nextInt();
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getNumestrellas() == estrellas) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel con el numero de estrellas " + estrellas);
				}
				break;

			// FIltro por habitacione sindivuduales
			case 6:
				seguir = false;
				int hab_ind = 0;
				do {
					try {
						System.out.println("Introduce el numero de habitaciones individuales");
						hab_ind = sc.nextInt();
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getHab_indi() == hab_ind) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel con este numero de habitaciones individuales " + hab_ind);
				}
				break;

			// Filtro por habitaciones dobles
			case 7:
				seguir = false;
				int hab_dobles = 0;
				do {
					try {
						System.out.println("Introduce el numero de habitaciones dobles");
						hab_dobles = sc.nextInt();
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getHab_dobles() == hab_dobles) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel con este numero de habitaciones dobles " + hab_dobles);
				}
				break;

			// Filtro por habitaciones triples
			case 8:
				seguir = false;
				int hab_triples = 0;
				do {
					try {
						System.out.println("Introduce el numero de habitaciones triples");
						hab_triples = sc.nextInt();
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getHab_triples() == hab_triples) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel con este numero de habitaciones triples " + hab_triples);
				}
				break;

			// Filtro por suits
			case 9:
				seguir = false;
				int suites = 0;
				do {
					try {
						System.out.println("Introduce el numero de suites");
						suites = sc.nextInt();
						seguir = true;
					} catch (InputMismatchException e) {
						System.err.println("Introduzca n�meros");
						sc.nextLine();
					}
				} while (seguir == false);

				for (int i = 0; i < lista.size(); i++) {
					if (lista.get(i).getSuites() == suites) {
						encontrado = true;
						j = i;
					}
				}
				if (encontrado) {
					System.out.print(lista.get(j).toString());
				} else {
					System.out.println("No existe nigun hotel con este numero de suites " + suites);
				}
				break;

			// Solo mostramos, no realizamos ningun cambio

			}
		} while (opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4 && opcion != 5 && opcion != 6 && opcion != 7
				&& opcion != 8 && opcion != 9);
	}
}