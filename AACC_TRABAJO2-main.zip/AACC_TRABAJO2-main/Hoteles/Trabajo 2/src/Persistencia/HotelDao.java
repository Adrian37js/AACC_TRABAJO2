package Persistencia;

import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import Dominio.Hotel;

public class HotelDao {
	
	public HotelDao() {
	}

	//Metodo ESCRIBIR xml
	public static void escribirXML(ArrayList<Hotel> lista) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.newDocument();
			Element eRaiz = doc.createElement("hoteles");
			doc.appendChild(eRaiz);
			for (int i = 0; i < lista.size(); i++) {
				
		//Nodoooooooo
				
				Element eHotel = doc.createElement("hotel");
				eRaiz.appendChild(eHotel);

			// atributo para el nodo hotel
				
				Attr attr2 = doc.createAttribute("foto");    //atrr foto
				attr2.setValue((lista.get(i).getFoto()));
				eHotel.setAttributeNode(attr2);
				
				Attr attr = doc.createAttribute("nombre");    //atrr nombre
				attr.setValue((lista.get(i).getNombre()));
				eHotel.setAttributeNode(attr);
				
				Attr attr3 = doc.createAttribute("id");    //atrr nombre
				attr3.setValue(Integer.toString(lista.get(i).getId()));
				eHotel.setAttributeNode(attr3);
			// Elementos
				
				//tel
				Element eTel = doc.createElement("tel");
				eTel.appendChild(doc.createTextNode(Integer.toString(lista.get(i).getTel())));
				eHotel.appendChild(eTel);
				//direccion
				Element eDireccion = doc.createElement("direccion");
				eDireccion.appendChild(doc.createTextNode(lista.get(i).getDireccion()));
				eHotel.appendChild(eDireccion);
				//ciudad
				Element eCiudad = doc.createElement("ciudad");
				eCiudad.appendChild(doc.createTextNode(lista.get(i).getCiudad()));
				eHotel.appendChild(eCiudad);
				//pais
				Element ePais = doc.createElement("pais");
				ePais.appendChild(doc.createTextNode(lista.get(i).getPais()));
				eHotel.appendChild(ePais);
				//numestrellas
				Element enumestrellas = doc.createElement("numestrellas");
				enumestrellas.appendChild(doc.createTextNode(Integer.toString(lista.get(i).getNumestrellas())));
				eHotel.appendChild(enumestrellas);
				//habindi
				Element ehab_indi = doc.createElement("hab_indi");
				ehab_indi.appendChild(doc.createTextNode(Integer.toString(lista.get(i).getHab_indi())));
				eHotel.appendChild(ehab_indi);
				//habdobles
				Element ehab_dobles = doc.createElement("hab_dobles");
				ehab_dobles.appendChild(doc.createTextNode(Integer.toString(lista.get(i).getHab_dobles())));
				eHotel.appendChild(ehab_dobles);
				//habtriples
				Element ehab_triples = doc.createElement("hab_triples");
				ehab_triples.appendChild(doc.createTextNode(Integer.toString(lista.get(i).getHab_triples())));
				eHotel.appendChild(ehab_triples);
				//suites
				Element esuites = doc.createElement("suites");
				esuites.appendChild(doc.createTextNode(Integer.toString(lista.get(i).getSuites())));
				eHotel.appendChild(esuites);
			}
				//Transofmramos
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("hotel.xml"));

			transformer.transform(source, result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	//Metodo LEER xml
	public static ArrayList<Hotel> leerXML() {
		File file = new File("hotel.xml");
		ArrayList<Hotel> lista = new ArrayList<Hotel>();

		try {
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(file);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("hotel");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					
					//Atributos
					String nombre = eElement.getAttribute("nombre");
					int id = Integer.parseInt(eElement.getAttribute("id"));
					String foto = eElement.getAttribute("foto");
					
					//Elemtnos
					int tel = Integer.parseInt(eElement.getElementsByTagName("tel").item(0).getTextContent());
					String direccion =  eElement.getElementsByTagName("direccion").item(0).getTextContent();
					String ciudad =  eElement.getElementsByTagName("ciudad").item(0).getTextContent();
					String pais =  eElement.getElementsByTagName("pais").item(0).getTextContent();
					int numestrellas =  Integer.parseInt(eElement.getElementsByTagName("numestrellas").item(0).getTextContent());
					int hab_indi =  Integer.parseInt(eElement.getElementsByTagName("hab_indi").item(0).getTextContent());
					int hab_dobles =  Integer.parseInt(eElement.getElementsByTagName("hab_dobles").item(0).getTextContent());
					int hab_triples =  Integer.parseInt(eElement.getElementsByTagName("hab_triples").item(0).getTextContent());
					int suites =  Integer.parseInt(eElement.getElementsByTagName("suites").item(0).getTextContent());
					
					//A�adir 
					Hotel newHotel = new Hotel(id, nombre,foto, tel,direccion,ciudad,pais,numestrellas,hab_indi,hab_dobles,hab_triples,suites);
					lista.add(newHotel);
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista;
	}
}